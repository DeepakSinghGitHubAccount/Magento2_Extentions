<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_Googleshoppingfeed
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\Googleshoppingfeed\Controller\Adminhtml\Items;

class Index extends \Webstraxt\Googleshoppingfeed\Controller\Adminhtml\Items
{
    /**
     * Items list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Webstraxt_Googleshoppingfeed::test');
        $resultPage->getConfig()->getTitle()->prepend(__('Google Shopping > Data Feeds'));
        $resultPage->addBreadcrumb(__('Google Shopping > Data Feeds'), __('Google Shopping > Data Feeds'));
        $resultPage->addBreadcrumb(__('Google Shopping > Data Feeds'), __('Feed Data'));
        return $resultPage;
    }
}