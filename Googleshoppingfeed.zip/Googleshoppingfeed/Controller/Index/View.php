<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_Googleshoppingfeed
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\Googleshoppingfeed\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\NotFoundException;
use Webstraxt\Googleshoppingfeed\Block\GoogleshoppingfeedView;

class View extends \Magento\Framework\App\Action\Action
{
	protected $_googleshoppingfeedview;

	public function __construct(
        Context $context,
        GoogleshoppingfeedView $googleshoppingfeedview
    ) {
        $this->_googleshoppingfeedview = $googleshoppingfeedview;
        parent::__construct($context);
    }

	public function execute()
    {
    	if(!$this->_googleshoppingfeedview->getSingleData()){
    		throw new NotFoundException(__('Parameter is incorrect.'));
    	}
    	
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
    }
}
