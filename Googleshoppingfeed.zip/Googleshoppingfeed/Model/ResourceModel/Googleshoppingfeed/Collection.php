<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_Googleshoppingfeed
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\Googleshoppingfeed\Model\ResourceModel\Googleshoppingfeed;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'googleshoppingfeed_id';
    /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'Webstraxt\Googleshoppingfeed\Model\Googleshoppingfeed',
            'Webstraxt\Googleshoppingfeed\Model\ResourceModel\Googleshoppingfeed'
        );
    }
}