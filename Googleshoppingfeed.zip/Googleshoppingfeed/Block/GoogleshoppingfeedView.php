<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_Googleshoppingfeed
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\Googleshoppingfeed\Block;

use Magento\Framework\View\Element\Template\Context;
use Webstraxt\Googleshoppingfeed\Model\GoogleshoppingfeedFactory;
use Magento\Cms\Model\Template\FilterProvider;
/**
 * Googleshoppingfeed View block
 */
class GoogleshoppingfeedView extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Googleshoppingfeed
     */
    protected $_googleshoppingfeed;
    public function __construct(
        Context $context,
        GoogleshoppingfeedFactory $googleshoppingfeed,
        FilterProvider $filterProvider
    ) {
        $this->_googleshoppingfeed = $googleshoppingfeed;
        $this->_filterProvider = $filterProvider;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Webstraxt Googleshoppingfeed Module View Page'));
        
        return parent::_prepareLayout();
    }

    public function getSingleData()
    {
        $id = $this->getRequest()->getParam('id');
        $googleshoppingfeed = $this->_googleshoppingfeed->create();
        $singleData = $googleshoppingfeed->load($id);
        if($singleData->getGoogleshoppingfeedId() && $singleData->getStatus() == 1){
            return $singleData;
        }else{
            return false;
        }
    }
}