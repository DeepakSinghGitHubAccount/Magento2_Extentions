<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_Googleshoppingfeed
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\Googleshoppingfeed\Block;

use Magento\Framework\View\Element\Template\Context;
use Webstraxt\Googleshoppingfeed\Model\GoogleshoppingfeedFactory;
/**
 * Googleshoppingfeed List block
 */
class GoogleshoppingfeedListData extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Googleshoppingfeed
     */
    protected $_googleshoppingfeed;
    public function __construct(
        Context $context,
        GoogleshoppingfeedFactory $googleshoppingfeed
    ) {
        $this->_googleshoppingfeed = $googleshoppingfeed;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Webstraxt Googleshoppingfeed Module List Page'));
        
        if ($this->getGoogleshoppingfeedCollection()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'webstraxt.googleshoppingfeed.pager'
            )->setAvailableLimit(array(5=>5,10=>10,15=>15))->setShowPerPage(true)->setCollection(
                $this->getGoogleshoppingfeedCollection()
            );
            $this->setChild('pager', $pager);
            $this->getGoogleshoppingfeedCollection()->load();
        }
        return parent::_prepareLayout();
    }

    public function getGoogleshoppingfeedCollection()
    {
        $page = ($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        $pageSize = ($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : 5;

        $googleshoppingfeed = $this->_googleshoppingfeed->create();
        $collection = $googleshoppingfeed->getCollection();
        $collection->addFieldToFilter('status','1');
        //$googleshoppingfeed->setOrder('googleshoppingfeed_id','ASC');
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);

        return $collection;
    }

    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }
}