<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_Googleshoppingfeed
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\Googleshoppingfeed\Block\Adminhtml\Items\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;

class Filters extends Generic implements TabInterface
{
    protected $_wysiwygConfig;
    protected $_objectManager;
    
    public function __construct(
        \Magento\Backend\Block\Template\Context $context, 
        \Magento\Framework\Registry $registry, 
        \Magento\Framework\Data\FormFactory $formFactory,  
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Magento\Framework\ObjectManagerInterface $objectManager,

        array $data = []
    ) 
    {
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_objectManager = $objectManager;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Filters');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Filters');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('current_webstraxt_googleshoppingfeed_items');
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('item_');
        
        $this->setTemplate('Webstraxt_Googleshoppingfeed::filters.phtml');

        $form->setValues($model->getData());
        $this->setForm($form);
        return parent::_prepareForm();
    }

    /**
    * Options getter.
    *
    * @return array
    */
    public function getProductTypes()
    {
        $data = [
        'simple' => 'Simple',
        'downloadable' => 'Downloadable',
        'virtual' => 'Virtual',
        'configurable' => 'Configurable',
        'grouped' => 'Grouped Product',
        'bundle' => 'Bundle Product',
        ];

      return $data;
    }

    /**
    * Return the product visibilty options.
    *
    * @return \Magento\Catalog\Model\Product\Visibility
    */
    
    public function getVisibilityOptionArray()
    {
        return $this->_objectManager->create(
        'Magento\Catalog\Model\Product\Visibility'
        )->getOptionArray();
    }

    public function getAtrributeSet()
    {
        return $this->_objectManager->create(
            '\Magento\Catalog\Model\Product\AttributeSet\Options'
        )->toOptionArray(); 
    }
}
