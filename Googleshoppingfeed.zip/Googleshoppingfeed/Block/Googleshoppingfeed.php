<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_Googleshoppingfeed
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\Googleshoppingfeed\Block;

/**
 * Googleshoppingfeed content block
 */
class Googleshoppingfeed extends \Magento\Framework\View\Element\Template
{
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context
    ) {
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Webstraxt Googleshoppingfeed Module'));
        
        return parent::_prepareLayout();
    }
}
