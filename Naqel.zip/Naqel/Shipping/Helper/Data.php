<?php

namespace Naqel\Shipping\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{

  protected $_scopeConfig;

  public function __construct(
      \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig 
  ) { 
      $this->scopeConfig = $scopeConfig;
  }  

  const XML_PATH_HELLOWORLD = 'carriers/';

  public function getConfigValue($field, $storeId = null)
  {

    return $this->scopeConfig->getValue($field, ScopeInterface::SCOPE_STORE, $storeId);
  }

  public function getNaqelClientConfig($code, $storeId = null)
  {

    return $this->getConfigValue(self::XML_PATH_HELLOWORLD .'naqel_shipping/'. $code, $storeId);
  }

  public function getNaqelClientInfo()
  {
    $ClientInfo = array(

                   'ClientAddress' => array(

                          'PhoneNumber'  => $this->getNaqelClientConfig('client_phone_no'),
                          'POBox'        => $this->getNaqelClientConfig('client_po_box'),
                          'ZipCode'      => $this->getNaqelClientConfig('client_zip_code'),
                          'Fax'          => $this->getNaqelClientConfig('client_fax'),
                          'FirstAddress' => $this->getNaqelClientConfig('client_first_address'),
                          'Location'     => $this->getNaqelClientConfig('client_location'),
                          'CountryCode'  => $this->getNaqelClientConfig('client_country_code'),
                          'CityCode'     => $this->getNaqelClientConfig('client_city_code'),

                    ),
                   'ClientContact' => array(

                          'Name'        => $this->getNaqelClientConfig('client_name'),
                          'Email'       => $this->getNaqelClientConfig('client_email'),
                          'PhoneNumber' => $this->getNaqelClientConfig('client_phone_no'),
                          'MobileNo'    => $this->getNaqelClientConfig('client_mobile_no')

                    ),
                    'ClientID'    => $this->getNaqelClientConfig('client_id'),
                    'Password'    => $this->getNaqelClientConfig('password'),
                    'Version'     => $this->getNaqelClientConfig('naqel_api_version')

          );

    return $ClientInfo;
  }


  public function callNaqelSoapApi()
  {

      $wsdlUrl = $this->getNaqelClientConfig('naqel_api_endpoint_url');
      //"https://infotrack.naqelexpress.com/NaqelAPIServices/NaqelAPIDemo/9.0/XMLShippingService.asmx?wsdl";

      $soapClient = new \SoapClient($wsdlUrl, array(
                      "trace" => true,
                      'cache_wsdl' => WSDL_CACHE_NONE));

      return $soapClient;

  }


}