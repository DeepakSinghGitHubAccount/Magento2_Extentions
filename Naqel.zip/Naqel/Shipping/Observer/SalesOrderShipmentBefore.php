<?php 
namespace Naqel\Shipping\Observer;

use Magento\Framework\Event\ObserverInterface;
use Naqel\Shipping\Model\WaybillFactory;
use Naqel\Shipping\Helper\Data;
class SalesOrderShipmentBefore implements ObserverInterface
{ 
  
    protected $helperData;
    protected $_WaybillFactory;
	  protected $_order_id; 
    private $responseFactory;
    private $url;
    protected $redirect;
    protected $messageManager;
    public function __construct(
        \Naqel\Shipping\Helper\Data $helperData,
        \Naqel\Shipping\Model\WaybillFactory  $WaybillFactory,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\App\Response\RedirectInterface $redirect)
    {
      $this->helperData = $helperData;
      $this->_WaybillFactory = $WaybillFactory;
       $this->messageManager = $messageManager;
      $this->responseFactory = $responseFactory;
      $this->url = $url;
      $this->redirect = $redirect;  

    } 

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        
        

        $shipment = $observer->getEvent()->getShipment();
        $order = $shipment->getOrder();
        
        $this->_order_id =  $order->getId();

        $increment_id = $order->getIncrementId();
        
        $grand_total_price = $order->getGrandTotal();
        
        $PicesCount = intval($order->getData('total_qty_ordered'));
  

        if(!$order->getId())
        {
            return;
        }
        
        try 
        {


            $data = array();
            $main = array();
            $shipping_method = $order->getShippingMethod();
            $payment_code = $order->getPayment()->getMethodInstance()->getCode();
            $payment_title = $order->getPayment()->getMethodInstance()->getTitle();

            if($shipping_method == 'naqel_shipping_naqel_shipping'){

                    $customerDetail =  $order->getShippingAddress()->getData();  
        
                    $ConsigneeName = $customerDetail['firstname']." ".$customerDetail['lastname'];

                    $ConsigneeAddress = $customerDetail['street']." ".$customerDetail['city'].", "
                                           .$customerDetail['postcode']." ".$customerDetail['region'].", "
                                           .$customerDetail['country_id'];

                    $_apiRequiredDataArray = array(
                        'ConsigneeNationalID' => 12345,
                        'DeliveryInstruction' => 'DeliveryInstruction',

                        'Fax'           => 1234,
                        'Near'          => 'near',
                        'ConsigneeName' => $ConsigneeName,
                        'Email'         => $customerDetail['email'],
                        'Mobile'        => $customerDetail['telephone'],
                        'PhoneNumber'   => $customerDetail['telephone'],
                        'Address'       => $ConsigneeAddress,
                        'CountryCode'   => 'KSA',
                        'CityCode'      => 'ABT',                  
                        'RefNo'         => 'RefNo123',
                        'InvoiceNo'     => 'InvoiceNo123', 
                        'InvoiceDate'   => date('Y-m-d'),
                        'TotalCost'     => $grand_total_price,

                        'CurrencyCode' => 'USA',
                        'CurrenyID'    => 0,
                        'BillingType'  => 5,
                        'PicesCount'   => $PicesCount,
                        'Weight'       => 10,
                        'CODCharge'    => 0,
                        'CreateBooking' => true,
                        'isRTO'         => false,
                        'GeneratePiecesBarCodes' => true,
                        'InsuredValue' => 0,
                        'IsInsurance'  => false,
                        'LoadTypeID'   => 36,
                        'DeclareValue' => 0,
                        'GoodDesc'     => 'GoodDesc',
                        'IsCustomDutyPayByConsignee' => false

                    );
                    
                    $this->CreateWaybill($_apiRequiredDataArray);
                    
                    
                }

            //die('yes');
        
        }catch (\Exception $e) {
		      
          $this->returnBackWithError($e->getMessage());
		   } 
      
    }

    public function CreateWaybill($_apiRequiredDataArray)
    {

      try{

              $ClientInfo         = $this->helperData->getNaqelClientInfo();
              $ConsigneeInfo      = $this->_createConsigneeInfoArray($_apiRequiredDataArray); 
              $_CommercialInvoice = $this->_create_CommercialInvoiceArray($_apiRequiredDataArray);


              $createWaybillapiRequestData = array(

                   '_ManifestShipmentDetails' => array(

                         'ClientInfo'                 => $ClientInfo, //array
                         'ConsigneeInfo'              => $ConsigneeInfo, //array
                         '_CommercialInvoice'         => $_CommercialInvoice, //array
                         'CurrenyID'                  => $_apiRequiredDataArray['CurrenyID'],
                         'BillingType'                => $_apiRequiredDataArray['BillingType'],
                         'PicesCount'                 => $_apiRequiredDataArray['PicesCount'],
                         'Weight'                     => $_apiRequiredDataArray['Weight'],
                         'DeliveryInstruction'        => $_apiRequiredDataArray['DeliveryInstruction'],
                         'CODCharge'                  => $_apiRequiredDataArray['CODCharge'],
                         'CreateBooking'              => $_apiRequiredDataArray['CreateBooking'],
                         'isRTO'                      => $_apiRequiredDataArray['isRTO'],
                         'GeneratePiecesBarCodes'     => $_apiRequiredDataArray['GeneratePiecesBarCodes'],
                         'InsuredValue'               => $_apiRequiredDataArray['InsuredValue'],
                         'IsInsurance'                => $_apiRequiredDataArray['IsInsurance'],
                         'LoadTypeID'                 => $_apiRequiredDataArray['LoadTypeID'],
                         'DeclareValue'               => $_apiRequiredDataArray['DeclareValue'],
                         'GoodDesc'                   => $_apiRequiredDataArray['GoodDesc'],
                         /*'Latitude'                   => $_apiRequiredDataArray['Latitude'],
                         'Longitude'                  => $_apiRequiredDataArray['Longitude'],*/
                         'RefNo'                      => $_apiRequiredDataArray['RefNo'],
                         // 'Reference1'                 => $_apiRequiredDataArray['Reference1'],
                         // 'Reference2'                 => $_apiRequiredDataArray['Reference2'],
                         // 'GoodsVATAmount'             => $_apiRequiredDataArray['GoodsVATAmount'],
                         'IsCustomDutyPayByConsignee' => $_apiRequiredDataArray['IsCustomDutyPayByConsignee']

                   )

              );
               $this->_callNaqelApi($createWaybillapiRequestData);
               

        }catch(\Exception $e)
        {
          $this->returnBackWithError($e->getMessage());
        }

    }

   /* public function _createClientInfoArray()
    {
      try{

            $ClientInfo = array(

                   'ClientAddress' => array(

                          'PhoneNumber'  => "1234567890",
                          'POBox'        => "123456",
                          'ZipCode'      => "123456",
                          'Fax'          => "123456",
                          'FirstAddress' => "client FirstAddress",
                          'Location'     => "test Location",
                          'CountryCode'  => "KSA",
                          'CityCode'     => "ABT",

                    ),
                   'ClientContact' => array(

                          'Name'        => "test client",
                          'Email'       => "test@mail.test",
                          'PhoneNumber' => "1234567890",
                          'MobileNo'    => "1234567890"

                    ),
                    'ClientID'    => "9018543",
                    'Password'    => "test1234",
                    'Version'     => "9.0"


          );
         
          return $ClientInfo;

      }catch(\Exception $e)
      {
        $this->returnBackWithError($e->getMessage());
      }
            
    }*/

    public function _createConsigneeInfoArray($_apiRequiredDataArray)
    {

      try{

            $consigneeInfo = array(

                  'ConsigneeNationalID' => $_apiRequiredDataArray['ConsigneeNationalID'],
                  'ConsigneeName'       => $_apiRequiredDataArray['ConsigneeName'],
                  'Email'               => $_apiRequiredDataArray['Email'],
                  'Mobile'              => $_apiRequiredDataArray['Mobile'],
                  'PhoneNumber'         => $_apiRequiredDataArray['PhoneNumber'],
                  'Fax'                 => $_apiRequiredDataArray['Fax'],
                  'Address'             => $_apiRequiredDataArray['Address'],
                  'Near'                => $_apiRequiredDataArray['Near'],
                  'CountryCode'         => $_apiRequiredDataArray['CountryCode'],
                  'CityCode'            => $_apiRequiredDataArray['CityCode']   

             );
          
            return $consigneeInfo;

      }
      catch(\Exception $e)
        {
          $this->returnBackWithError($e->getMessage());
        }      

    }

    public function _create_CommercialInvoiceArray($_apiRequiredDataArray)
    { 
          try{

              $_CommercialInvoice = array(
               
                     'RefNo'             => $_apiRequiredDataArray['RefNo'],
                     'InvoiceNo'         => $_apiRequiredDataArray['InvoiceNo'],
                     'InvoiceDate'       => $_apiRequiredDataArray['InvoiceDate'],
                     'Consignee'         => $_apiRequiredDataArray['ConsigneeName'],
                     'ConsigneeAddress'  => $_apiRequiredDataArray['Address'],
                     'ConsigneeEmail'    => $_apiRequiredDataArray['Email'],
                     'MobileNo'          => $_apiRequiredDataArray['Mobile'],
                     'Phone'             => $_apiRequiredDataArray['PhoneNumber'],
                     'TotalCost'         => $_apiRequiredDataArray['TotalCost'],
                     'CurrencyCode'      => $_apiRequiredDataArray['CurrencyCode']
                       

               );

               return $_CommercialInvoice;


          }catch(\Exception $e)
          {
            $this->returnBackWithError($e->getMessage());
          }

    } 


    /**
     * call Naqel Api 
     *
     * @param array $apiData
     * 
     * @return array
     */
    public function _callNaqelApi($apiRequestData)
    {

        try{

          $soapClient = $this->helperData->callNaqelSoapApi();
          
          $response = $soapClient->CreateWaybill($apiRequestData);

          //var_dump($soapClient);  
          //echo "<br>";

          $apiResponseData = json_decode(json_encode($response),true);
          
          return $this->_saveNaqelApiResponseDB($apiResponseData['CreateWaybillResult']);

        }catch(\Exception $e)
        {
          $this->returnBackWithError($e->getMessage());
        }
    }

    /**
     * save Naqel Api response to database
     *
     * @param array $apiResponseData
     * 
     * @return bool
     */
    public function _saveNaqelApiResponseDB($apiResponseData)
    {

        try{


            if($apiResponseData["HasError"] ==1)
            {

              $this->returnBackWithError("Naqel Client Error :" . $apiResponseData["Message"]);

            }else
            {

              $insertData = array(
                "order_id"       => $this->_order_id,  
                "has_error"      => isset($apiResponseData["HasError"]) ? $apiResponseData["HasError"] : '' ,
                "waybill_no"     => isset($apiResponseData["WaybillNo"]) ? $apiResponseData["WaybillNo"] : '',
                "booking_ref_no" => isset($apiResponseData["BookingRefNo"]) ? $apiResponseData["BookingRefNo"] :'',
                "waybill_key"    => isset($apiResponseData["Key"]) ? $apiResponseData["Key"] : '',
                "message"        => isset($apiResponseData["Message"]) ? $apiResponseData["Message"] : '',
                "created_at"     => date('Y-m-d H:i:s')
                );

                $query_result = $this->_WaybillFactory->create()->setData($insertData)->save();
                if($query_result)
                {
                  return TRUE;
                }else
                {
                  return FALSE;
                }
              

            }

            

        }catch(\Exception $e)
        {
           $this->returnBackWithError($e->getMessage());
           
          
        }
    }


    public function returnBackWithError($errorMessage)
    {
        $this->messageManager->addError("Naqel Shipping :- " . $errorMessage);
        $redirectUrl = $this->redirect->getRedirectUrl();
        $this->responseFactory->create()->setRedirect($redirectUrl)->sendResponse();
        die();
    }


}