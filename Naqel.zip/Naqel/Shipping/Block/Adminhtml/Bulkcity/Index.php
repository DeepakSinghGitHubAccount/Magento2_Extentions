<?php
namespace Naqel\Shipping\Block\Adminhtml\Bulkcity;
class Index extends \Magento\Backend\Block\Template
{

	
}
