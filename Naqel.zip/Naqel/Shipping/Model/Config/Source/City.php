<?php

namespace Naqel\Shipping\Model\Config\Source;

class City implements \Magento\Framework\Option\ArrayInterface
{ 
    /**
     * 
     * @return array
     */
    public function toOptionArray()
    {
        // return data from naqel_shipping_naqel_city table  
        $objectManager =   \Magento\Framework\App\ObjectManager::getInstance();
         $connection = $objectManager->get('Magento\Framework\App\ResourceConnection')->getConnection('\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION'); 

      $cityData = $connection->fetchAll("SELECT * FROM naqel_shipping_naqel_city");
       
      $optionsArray = array(); 
      $optionsArray[''] = "Select City";
      foreach ($cityData as $key => $city) 
      {
        $optionsArray[$city['code']] = $city['city_name'];      
      }

      return $optionsArray;


    }


}