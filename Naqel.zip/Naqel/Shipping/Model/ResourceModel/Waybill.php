<?php
namespace Naqel\Shipping\Model\ResourceModel;


class Waybill extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	
	public function __construct(
		\Magento\Framework\Model\ResourceModel\Db\Context $context
	)
	{
		parent::__construct($context);
	}
	
	protected function _construct()
	{
		$this->_init('naqel_shipping_waybill_record', 'waybill_id');
	}
	
}