<?php

namespace Naqel\Shipping\Controller\Adminhtml\GetWaybillSticker;

use Naqel\Shipping\Model\WaybillFactory;

ob_start();

class Index extends \Magento\Framework\App\Action\Action
{
  protected $_pageFactory;
  protected $_WaybillFactory;
  protected $request;
  protected $helperData;
  protected $messageManager;

  public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Framework\Message\ManagerInterface $messageManager,
    \Magento\Framework\View\Result\PageFactory $pageFactory,
    \Magento\Framework\App\Request\Http $request,
    \Naqel\Shipping\Model\WaybillFactory  $WaybillFactory,
    \Naqel\Shipping\Helper\Data $helperData
    )
  {
    $this->_pageFactory = $pageFactory;
    $this->messageManager = $messageManager;
    $this->request = $request;
    $this->helperData = $helperData;
    $this->_WaybillFactory = $WaybillFactory;
    parent::__construct($context);
  }


  public function execute(){
   
    
     //var_dump($this->helperData->getNaqelClientInfo());

      $data['order_id'] =  $this->request->getParam('order_id');
      
      
      if(isset($data['order_id']) && $data['order_id'] !='')
      {
          try{

              $order_id = $data['order_id'];

               $waybill_data = $this->_WaybillFactory->create()->getCollection ()->addFieldToFilter('order_id', array('eq' => $order_id))->getData(); 

              
              

              $order_waybill_no  = $waybill_data[0]['waybill_no'];

              if(isset($order_waybill_no) && $order_waybill_no !='')
               {

                  $clientInfo = $this->helperData->getNaqelClientInfo();

                  $apiRequestData = array(

                      'clientInfo' => $clientInfo,
                      'WaybillNo'  =>  $order_waybill_no,
                      'StickerSize' => 'A4'
                  );      

                  $apiResponse = $this->_callNaqelGetWaybillStickerApi($apiRequestData);
                  
                  header("Content-disposition: attachment; filename=sticker.pdf");
                  header("Content-type: application/pdf");
                  
                  print_r($apiResponse);
                  exit();

               } 

          }catch(\Exception $e)
          {
            echo $e->getMessage();
            die('qwqwqwq1111');
          }


      }else
      {
        echo "order_id required";
        die();
        
      }

      
      


  }

  public function _callNaqelGetWaybillStickerApi($apiRequestData)
    {

        try{   

            $soapClient = $this->helperData->callNaqelSoapApi();

            $response = $soapClient->GetWaybillSticker($apiRequestData);

            return $response->GetWaybillStickerResult;

        }catch(\Exception $e)
        {
          echo $e->getMessage();
          die('qwqwqwq00000');
        }

    }

    
}