<?php

namespace Naqel\Shipping\Controller\Index;
use Naqel\Shipping\Model\WaybillFactory;

ob_start();

class Index extends \Magento\Framework\App\Action\Action
{
  protected $_pageFactory;
  protected $_WaybillFactory;
  protected $request;
  protected $helperData;

  public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Framework\View\Result\PageFactory $pageFactory,
    \Magento\Framework\App\Request\Http $request,
    \Naqel\Shipping\Model\WaybillFactory  $WaybillFactory,
    \Naqel\Shipping\Helper\Data $helperData
    )
  {
    $this->_pageFactory = $pageFactory;
    $this->request = $request;
    $this->helperData = $helperData;
    $this->_WaybillFactory = $WaybillFactory;
    parent::__construct($context);
  }


  public function execute(){


      $data = $this->getRequest()->getPostValue();
      
      if(isset($data['order_id']) && $data['order_id'] !='')
      {
          try{

              $order_id = $data['order_id'];

               $waybill_data = $this->_WaybillFactory->create()->getCollection ()->addFieldToFilter('order_id', array('eq' => $order_id))->getData(); 

              
              

              $order_waybill_no  = $waybill_data[0]['waybill_no'];
              
              if(isset($order_waybill_no) && $order_waybill_no !='')
               {

                  $ClientInfo = $this->helperData->getNaqelClientInfo();
                  $apiRequestData = array(

                      'ClientInfo' => $ClientInfo,
                      'WaybillNo'  =>  $order_waybill_no //80025140
                  );      

                  $apiResponse = $this->_callNaqelApi($apiRequestData);
                  

                  $ajaxResponse = "<table class='table table-bordered track_tbl'>";
                  $ajaxResponse .= "<thead><tr><th></th><th>S.NO</th><th>STATUS</th><th>SHIPPING</th><th>DATE/TIME</th></tr></thead>";
                  $s_no=1;
                  $ajaxResponse .="<tbody>";
                  foreach ($apiResponse as $key => $value) 
                  {
                      
                      $ajaxResponse .= "<tr>";
                      $ajaxResponse .= "<td class='track_dot'><span class='track_line'></span></td>";
                      $ajaxResponse .= "<td>".$s_no++."</td>";
                      $ajaxResponse .= "<td>".$value['Activity']."</td>";
                      $ajaxResponse .= "<td>Naqel express</td>";
                      $ajaxResponse .= "<td>".date('j M Y g:i A',strtotime($value['Date']))."</td>";
                      
                      
                      $ajaxResponse .= "</tr>";
                  }

                  $ajaxResponse .= "</tbody></table>";
                  echo $ajaxResponse;
                  exit();

               } 

          }catch(\Exception $e)
          {
            echo $e->getMessage();
            die('qwqwqwq1111');
          }


      }else
      {
        die('order_id value required');
      }

      
      


  }

  public function _callNaqelApi($apiRequestData)
    {

        try{   
 
            $soapClient = $this->helperData->callNaqelSoapApi();

            $response = $soapClient->TraceByWaybillNo($apiRequestData);

            $apiResponseData = json_decode(json_encode($response),true);
            
            return $apiResponseData['TraceByWaybillNoResult']['Tracking'];

        }catch(\Exception $e)
        {
          echo $e->getMessage();
          die('qwqwqwq00000');
        }

    }
    
}