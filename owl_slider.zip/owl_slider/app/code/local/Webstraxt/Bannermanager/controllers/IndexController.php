<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
 
class Webstraxt_Bannermanager_IndexController extends Mage_Core_Controller_Front_Action
{	

	/**
	* load banner slider at frontend
	*/
	public function indexAction()
	{	
		$this->loadLayout();     
		$this->renderLayout();
	}
}