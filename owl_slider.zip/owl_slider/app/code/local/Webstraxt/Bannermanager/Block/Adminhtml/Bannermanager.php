<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class Webstraxt_Bannermanager_Block_Adminhtml_Bannermanager extends Mage_Adminhtml_Block_Widget_Grid_Container
{

	/**
     * Constructor
     *
     * @return void
     */
	public function __construct()
	{
		$this->_controller = 'adminhtml_bannermanager';
		$this->_blockGroup = 'bannermanager';
		$this->_headerText = Mage::helper('bannermanager')->__('Banner Info');
		$this->_addButtonLabel = Mage::helper('bannermanager')->__('Add New Banner');
		parent::__construct();
	}
}