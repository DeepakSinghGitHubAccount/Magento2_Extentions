<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class Webstraxt_Bannermanager_Block_Adminhtml_Bannermanager_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
  
  /**
   * Prepare form before rendering HTML
   *
   * @return $this
   */
  protected function _prepareForm()
  {
    $form = new Varien_Data_Form(array(
      'id' => 'edit_form',
      'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
      'method' => 'post',
      'enctype' => 'multipart/form-data'
    )
  );

    $form->setUseContainer(true);
    $this->setForm($form);
    return parent::_prepareForm();
  }
}