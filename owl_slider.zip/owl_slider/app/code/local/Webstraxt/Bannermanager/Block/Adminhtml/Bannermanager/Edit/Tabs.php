<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class Webstraxt_Bannermanager_Block_Adminhtml_Bannermanager_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  /**
   * Constructor
   *
   * @return void
   */
  public function __construct()
  {
    parent::__construct();
    $this->setId('bannermanager_tabs');
    $this->setDestElementId('edit_form');
    $this->setTitle(Mage::helper('bannermanager')->__('Banner Information'));
  }

  /**
   * Set grid page title
   *
   * @return $this
   */
  protected function _beforeToHtml()
  {
    $this->addTab('form_section', array(
      'label'     => Mage::helper('bannermanager')->__('Banner Information'),
      'title'     => Mage::helper('bannermanager')->__('Banner Information'),
      'content'   => $this->getLayout()->createBlock('bannermanager/adminhtml_bannermanager_edit_tab_form')->toHtml(),
    ));
    
    return parent::_beforeToHtml();
  }
}