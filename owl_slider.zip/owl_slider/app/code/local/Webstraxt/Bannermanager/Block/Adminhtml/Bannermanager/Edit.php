<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class Webstraxt_Bannermanager_Block_Adminhtml_Bannermanager_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{   

    /**
     * Constructor
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        
        $this->_objectId = 'id';
        $this->_blockGroup = 'bannermanager';
        $this->_controller = 'adminhtml_bannermanager';
        
        $this->_updateButton('save', 'label', Mage::helper('bannermanager')->__('Save Banner'));
        $this->_updateButton('delete', 'label', Mage::helper('bannermanager')->__('Delete Banner'));
        
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
        function toggleEditor() {
            if (tinyMCE.getInstanceById('bannermanager_content') == null) {
                tinyMCE.execCommand('mceAddControl', false, 'bannermanager_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'bannermanager_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
            ";
        }

        /**
         * Set admin header text in admin 
         *
         * @return string
         */
        public function getHeaderText()
        {
            if( Mage::registry('bannermanager_data') && Mage::registry('bannermanager_data')->getId() ) {
                return Mage::helper('bannermanager')->__("Edit Banner '%s'", $this->htmlEscape(Mage::registry('bannermanager_data')->getTitle()));
            } else {
                return Mage::helper('bannermanager')->__('Add Banner');
            }
        }
    }