<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

class Webstraxt_Bannermanager_Block_Bannermanager extends Mage_Core_Block_Template
{
 const SYSTEM_SECTION_NAME = "webstraxt";//system.xml config section name
 const SYSTEM_GROUP_NAME = "webstraxt_group";//system.xml config group name


/**
* prepareLayout
*
* @return $this
*/
public function _prepareLayout()
{
  return parent::_prepareLayout();
}


public function getBannermanager()     
{ 
  if (!$this->hasData('bannermanager')) {
    $this->setData('bannermanager', Mage::registry('bannermanager'));
  }
  return $this->getData('bannermanager');
  
}

/**
* get Banner Collection
*
* @return collect object
*/  
public function getBannerCollection()
{
  $collection = Mage::getModel('bannermanager/bannermanager')->getCollection()->addFieldToFilter('status', 1)->setOrder('sort_order', 'ASC');

  return $collection;
}

/**
* get media url for banner manager
*
* @return string
*/
public function getMediaUrl()
{
  return Mage::getBaseUrl("media")."webstraxt/bannermanager/";
}

/**
* get system config field value. 
*
* @return string
*/

public function getConfigFieldValue($fieldName)
{
   $store = Mage::app()->getStore(); // store info
   $configValue = Mage::getStoreConfig(self::SYSTEM_SECTION_NAME. '/' . self::SYSTEM_GROUP_NAME.'/'.$fieldName , $store); 
   return $configValue;
 }

/**
* get status of module
*
* @return 0/1
*/
 
 public function getModuleStatus()
 {
   return $this->getConfigFieldValue('webstraxt_enable'); 
 }

 /**
  * get system config for slider
  *
  * @return array
  */
  public function getSliderConfig()
  {

    $sliderConfig = array();

    $sliderConfig['autoPlay'] = $this->getConfigFieldValue('webstraxt_slider_autoplay');
    $sliderConfig['autoplayTimeout'] = $this->getConfigFieldValue('webstraxt_slider_autoplay_timeout');
    $sliderConfig['autoHeight'] = $this->getConfigFieldValue('webstraxt_slider_auto_height');
    $sliderConfig['autoplayHoverPause'] = $this->getConfigFieldValue('webstraxt_slider_autoplay_pause');  

    return $sliderConfig;   

  }

}