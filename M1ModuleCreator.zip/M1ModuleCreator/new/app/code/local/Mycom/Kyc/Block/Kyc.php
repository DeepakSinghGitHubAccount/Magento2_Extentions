<?php
class Mycom_Kyc_Block_Kyc extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getKyc()     
     { 
        if (!$this->hasData('kyc')) {
            $this->setData('kyc', Mage::registry('kyc'));
        }
        return $this->getData('kyc');
        
    }
}