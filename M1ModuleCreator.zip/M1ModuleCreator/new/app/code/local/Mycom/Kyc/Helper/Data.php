<?php

class Mycom_Kyc_Helper_Data extends Mage_Core_Helper_Abstract
{

}