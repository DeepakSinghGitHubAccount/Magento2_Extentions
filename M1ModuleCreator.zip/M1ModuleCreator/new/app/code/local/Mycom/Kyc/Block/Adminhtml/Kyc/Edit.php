<?php

class Mycom_Kyc_Block_Adminhtml_Kyc_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'kyc';
        $this->_controller = 'adminhtml_kyc';
        
        $this->_updateButton('save', 'label', Mage::helper('kyc')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('kyc')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('kyc_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'kyc_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'kyc_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('kyc_data') && Mage::registry('kyc_data')->getId() ) {
            return Mage::helper('kyc')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('kyc_data')->getTitle()));
        } else {
            return Mage::helper('kyc')->__('Add Item');
        }
    }
}