<?php
class Mycom_Kyc_Block_Adminhtml_Kyc extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_kyc';
    $this->_blockGroup = 'kyc';
    $this->_headerText = Mage::helper('kyc')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('kyc')->__('Add Item');
    parent::__construct();
  }
}