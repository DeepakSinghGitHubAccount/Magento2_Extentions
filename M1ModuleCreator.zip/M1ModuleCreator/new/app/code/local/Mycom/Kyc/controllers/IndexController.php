<?php
class Mycom_Kyc_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/kyc?id=15 
    	 *  or
    	 * http://site.com/kyc/id/15 	
    	 */
    	/* 
		$kyc_id = $this->getRequest()->getParam('id');

  		if($kyc_id != null && $kyc_id != '')	{
			$kyc = Mage::getModel('kyc/kyc')->load($kyc_id)->getData();
		} else {
			$kyc = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($kyc == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$kycTable = $resource->getTableName('kyc');
			
			$select = $read->select()
			   ->from($kycTable,array('kyc_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$kyc = $read->fetchRow($select);
		}
		Mage::register('kyc', $kyc);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}