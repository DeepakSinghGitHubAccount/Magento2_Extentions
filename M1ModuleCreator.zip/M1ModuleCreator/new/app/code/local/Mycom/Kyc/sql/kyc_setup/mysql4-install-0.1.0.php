<?php
/* @var $installer Ced_CsMarketplace_Model_Entity_Setup */
$installer = $this;
$installer->startSetup();	
/**
 * Create table 'vendor_shareholders_general'
 */
$installer->run("
		CREATE TABLE IF NOT EXISTS `{$installer->getTable('shareholders_kyc')}` (
		  `kyc_id` int(11) NOT NULL AUTO_INCREMENT,
		  `vendor_id` int(11) DEFAULT NULL COMMENT 'Vendor ID',
		  `type` varchar(200) NOT NULL COMMENT 'Type',
		  `first_name` varchar(200) NOT NULL COMMENT 'First Name',
		  `last_name` varchar(200) NOT NULL COMMENT 'Last Name',
		  `phone_no` varchar(200) NOT NULL COMMENT 'Phone Number',
		  `country` varchar(200) NOT NULL COMMENT 'Country',
		  `address` varchar(200) NOT NULL COMMENT 'Address',
		  `city` varchar(200) NOT NULL COMMENT 'City',
		  `state` varchar(200) NOT NULL COMMENT 'State',
		  `zip_code` varchar(200) NOT NULL COMMENT 'Zip Code',
		  `date_of_birth` varchar(200) NOT NULL COMMENT 'DOB',
		  `status` varchar(10) DEFAULT NULL,
		  `created_time` datetime NULL,
          `update_time` datetime NULL,
		  PRIMARY KEY (`kyc_id`)
		) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
	"); 

/* $installer->installVendorForms(); */
$installer->endSetup();