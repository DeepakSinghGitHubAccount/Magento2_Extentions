<?php

class <Namespace>_<Module>_Helper_Data extends Mage_Core_Helper_Abstract
{

}