<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\BannerManager\Model\ResourceModel;

class SliderManager extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('webstraxt_bannermanager_slider', 'slider_id');   //here "webstraxt_bannermanager" is table name and "bannermanager_id" is the primary key of custom table
    }
}