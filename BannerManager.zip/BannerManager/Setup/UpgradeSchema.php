<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
namespace Webstraxt\BannerManager\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
	public function upgrade( SchemaSetupInterface $setup, ModuleContextInterface $context ) {
		$installer = $setup;

		$installer->startSetup();

		if(version_compare($context->getVersion(), '1.1.0', '<')) {
			//add new column
			$installer->getConnection()->addColumn(
				$installer->getTable( 'webstraxt_bannermanager' ),
				'slider_id',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
					'nullable' => true,
					'length' => 10,
					'default' => 0,
					'comment' => 'slider_id',
					'after' => 'url'
				]
			);

			$installer->endSetup();

			// add new table webstraxt_bannermanager_slider
			$table = $installer->getConnection()->newTable(
	            $installer->getTable('webstraxt_bannermanager_slider')
	        )->addColumn(
	            'slider_id',
	            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
	            10,
	            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
	            'Slider ID'
	        )->addColumn(
	            'title',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            255,
	            ['nullable' => false, 'default' => ''],
	            'Slider title'
	        )->addColumn(
	            'store_id',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            255,
	            ['nullable' => true,'default' => null],
	            'Store Id'
	        )->addColumn(
	            'position',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            255,
	            ['nullable' => true],
	            'Slider position'
	        )->addColumn(
	            'show_title',
	            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
	            null,
	            ['nullable' => true, 'default' => '1'],
	            'Show Title'
	        )->addColumn(
	            'status',
	            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
	            null,
	            ['nullable' => false, 'default' => '1'],
	            'Slider status'
	        )->addColumn(
	            'animation_type',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            255,
	            ['nullable' => true],
	            'Slider animationB'
	        )->addColumn(
	            'description',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            null,
	            ['nullable' => true],
	            'Slider description'
	        )->addColumn(
	            'width',
	            \Magento\Framework\DB\Ddl\Table::TYPE_FLOAT,
	            10,
	            ['nullable' => true],
	            'Slider width'
	        )->addColumn(
	            'height',
	            \Magento\Framework\DB\Ddl\Table::TYPE_FLOAT,
	            10,
	            ['nullable' => true],
	            'Slider height'
	        )->addColumn(
	            'caption',
	            \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
	            null,
	            ['nullable' => true],
	            'Slider caption'
	        )->addColumn(
	            'slider_speed',
	            \Magento\Framework\DB\Ddl\Table::TYPE_FLOAT,
	            10,
	            ['nullable' => true],
	            'Slider speed'
	        )->addColumn(
	            'url_view',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            255,
	            ['nullable' => true],
	            'Slider url view'
	        );
	        $installer->getConnection()->createTable($table);

	        $installer->endSetup();
		}

	}
}