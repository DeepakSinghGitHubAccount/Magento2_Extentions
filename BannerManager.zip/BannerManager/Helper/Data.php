<?php



namespace Webstraxt\BannerManager\Helper;

use Webstraxt\BannerManager\Model\Slider;


class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Backend\Model\UrlInterface
     */
    protected $_backendUrl;

    /**
     * Store manager.
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * category collection factory.
     *
     * @var \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory
     */
    protected $_categoryCollectionFactory;

    /**
     * Slidermanager collection factory.
     *
     * @var \Webstraxt\BannerManager\Model\ResourceModel\Slider\CollectionFactory
     */
    protected $_sliderManagerFactory;
    
    /**
     * [__construct description].
     *
     * @param \Magento\Framework\App\Helper\Context                      $context              [description]
     * @param \Magento\Directory\Helper\Data                             $directoryData        [description]
     * @param \Magento\Directory\Model\ResourceModel\Country\Collection       $countryCollection    [description]
     * @param \Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regCollectionFactory [description]
     * @param \Magento\Store\Model\StoreManagerInterface                 $storeManager         [description]
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Magento\Backend\Model\UrlInterface $backendUrl,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Webstraxt\BannerManager\Model\ResourceModel\SliderManager\CollectionFactory $sliderManagerFactory
    ) {
        parent::__construct($context);
        $this->_backendUrl = $backendUrl;
        $this->_storeManager = $storeManager;
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->_sliderManagerFactory = $sliderManagerFactory;
    }

    /**
     * get Base Url Media.
     *
     * @param string $path   [description]
     * @param bool   $secure [description]
     *
     * @return string [description]
     */
    public function getBaseUrlMedia($path = '', $secure = false)
    {
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA, $secure) . $path;
    }



    /**
     * get Slider Banner Url
     * @return string
     */
    public function getSliderBannerUrl()
    {
        return $this->_backendUrl->getUrl('*/*/banners', ['_current' => true]);
    }

    /**
     * get Backend Url
     * @param  string $route
     * @param  array  $params
     * @return string
     */
    public function getBackendUrl($route = '', $params = ['_current' => true])
    {
        return $this->_backendUrl->getUrl($route, $params);
    }



    public function getAvilableSlider()
    {

         
        $sliderCollection = $this->_sliderManagerFactory->create()->getData();

        $sliderArray = array();
        foreach ($sliderCollection as $slider) {
            if (isset($slider['title']) && isset($slider['slider_id'])) {
                $sliderArray[] = array(
                    'label' => $slider['title'],
                    'value' => $slider['slider_id']
                );
            }
        }

        return $sliderArray;

    }


    /**
     *  Animation type
     * @return array
     */
    public function getAnimationType()
    {
        return [
            [
                'label' => __('Fade In'),
                'value' => 'fadeIn',
            ],
            [
                'label' => __('Fade Out'),
                'value' => 'fadeOut',
            ],
            [
                'label' => __('Zoom In'),
                'value' => 'zoomIn',
            ],
            [
                'label' => __('Zoom Out'),
                'value' => 'zoomOut',
            ],
            
            [
                'label' => __('Slide In Left'),
                'value' => 'slideInLeft',
            ],
            [
                'label' => __('Slide In Right'),
                'value' => 'slideInRight',
            ],
            [
                'label' => __('Slide Out Left'),
                'value' => 'slideOutLeft',
            ],
            [
                'label' => __('Slide Out Right'),
                'value' => 'slideOutRight',
            ],
            
            
        ];
    }



    /**
     * get Block Ids To Options Array
     * @return array
     */
    public function getBlockIdsToOptionsArray()
    {
        return [
            [
                'label' => __('------- Please choose position -------'),
                'value' => '',
            ],
            [
                'label' => __('Popular positions'),
                'value' => [
                    ['value' => 'cms-page-content-top', 'label' => __('Homepage-Content-Top')],
                ],
            ],
            [
                'label' => __('General (will be disaplyed on all pages)'),
                'value' => [
                    
                    ['value' => 'content-top', 'label' => __('Content-Top')],
                    ['value' => 'page-bottom', 'label' => __('Page-Bottom')],
                ],
            ],
            [
                'label' => __('Catalog and product'),
                'value' => [
                    ['value' => 'catalog-content-top', 'label' => __('Catalog-Content-Top')],
                    ['value' => 'catalog-page-bottom', 'label' => __('Catalog-Page-Bottom')],
                ],
            ],
            [
                'label' => __('Product only'),
                'value' => [
                    ['value' => 'product-content-top', 'label' => __('Product-Content-Top')],
                    ['value' => 'product-page-bottom', 'label' => __('Product-Page-Bottom')],
                ],
            ],
            [
                'label' => __('Customer'),
                'value' => [
                    ['value' => 'customer-content-top', 'label' => __('Customer-Content-Top')],
                    ['value' => 'customer-sidebar-main-top', 'label' => __('Customer-Siderbar-Main-Top')],
                    ['value' => 'customer-sidebar-main-bottom', 'label' => __('Customer-Siderbar-Main-Bottom')],
                ],
            ],
            [
                'label' => __('Cart & Checkout'),
                'value' => [
                    ['value' => 'cart-content-top', 'label' => __('Cart-Content-Top')],
                    ['value' => 'checkout-content-top', 'label' => __('Checkout-Content-Top')],
                ],
            ],
        ];
    }
 
}
