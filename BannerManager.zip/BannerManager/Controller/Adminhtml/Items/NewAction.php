<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\BannerManager\Controller\Adminhtml\Items;

class NewAction extends \Webstraxt\BannerManager\Controller\Adminhtml\Items
{

    public function execute()
    {
        $this->_forward('edit');
    }
}
