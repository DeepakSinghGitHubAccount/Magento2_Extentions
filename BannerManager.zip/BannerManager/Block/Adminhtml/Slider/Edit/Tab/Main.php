<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
namespace Webstraxt\BannerManager\Block\Adminhtml\Slider\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;

class Main extends Generic implements TabInterface
{
    protected $_wysiwygConfig;
    protected $_systemStore;
    protected $_websiteFactory;
    protected $_sliderHelper;
 
    public function __construct(
        \Magento\Backend\Block\Template\Context $context, 
        \Magento\Framework\Registry $registry, 
        \Magento\Framework\Data\FormFactory $formFactory,  
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig, 
        \Magento\Store\Model\WebsiteFactory $websiteFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Webstraxt\BannerManager\Helper\Data $sliderHelper,
        array $data = []
    ) 
    {
        $this->_systemStore = $systemStore;
        $this->_websiteFactory = $websiteFactory;
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_sliderHelper  = $sliderHelper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Slider Information');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Slider Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('current_webstraxt_bannermanager_slider');
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('item_');
        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Slider Information')]);
        if ($model->getId()) {
            $fieldset->addField('slider_id', 'hidden', ['name' => 'slider_id']);
        }
        $fieldset->addField(
            'title',
            'text',

            ['name' => 'title', 
            'label' => __('Title'), 
            'title' => __('Title'), 
            'required' => true,
          ]
        );
        

        $fieldset->addField(
            'width',
            'text',
            [
                'label' => __('Width'),
                'name' => 'width',
                'required' => true,
                'class' => 'required-entry validate-number validate-greater-than-zero',
                'note' => 'in pixel. (ex- 1000)',
            ]
        );
        
        $fieldset->addField(
            'height',
            'text',
            [
                'label' => __('Height'),
                'name' => 'height',
                'required' => true,
                'class' => 'required-entry validate-number validate-greater-than-zero',
                'note' => 'in pixel (ex- 350)',
            ]
        );    

        $fieldset->addField(
            'slider_speed',
            'text',
            [
                'label' => __('Speed'),
                'name' => 'slider_speed',
                'note' => 'milliseconds . This is the display time of a banner',
            ]
        );
        
        $fieldset->addField(
            'show_title',
            'select',
            ['name' => 'show_title',
             'label' => __('Show Title'), 
             'title' => __('Show Title'),  
             'options'   => [1 => 'Enable',0 => 'Disable' ], 
             'required' => false,
             'note' => 'show slider title on website'
         ]

        );

        $fieldset->addField(
            'animation_type',
            'select',
            [
                'label' => __('Animation Effect'),
                'name' => 'animation_type',
                'values' => $this->_sliderHelper->getAnimationType(),
            ]
        );
        $fieldset->addField(
            'position',
            'select',
            [
                'label' => __('Position'),
                'name' => 'position',
                'values' => $this->_sliderHelper->getBlockIdsToOptionsArray(),
            ]
        );

        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'),  'options'   => [1 => 'Enable',0 => 'Disable'], 'required' => false]
        );

        
        
        $websites = $this->_websiteFactory->create()->getCollection()->toOptionArray();

        if (!$this->_storeManager->isSingleStoreMode()) {
            $field = $fieldset->addField(
                'store_id',
                'multiselect',
                [
                    'name' => 'store_id[]',
                    'label' => __('Store View'),
                    'title' => __('Store View'),
                    'required' => true,
                    'values' => $this->_systemStore->getStoreValuesForForm(false, true)
                ]
            );
            $renderer = $this->getLayout()->createBlock(
                'Magento\Backend\Block\Store\Switcher\Form\Renderer\Fieldset\Element'
            );
            $field->setRenderer($renderer);
        } else {
            $fieldset->addField(
                'store_id',
                'hidden',
                ['name' => 'store_id[]', 'value' => $this->_storeManager->getStore(true)->getId()]
            );
            $model->setStoreIds($this->_storeManager->getStore(true)->getId());
        }
        
        $form->setValues($model->getData());
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
