<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
namespace Webstraxt\BannerManager\Block\Adminhtml\Items\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;

class Main extends Generic implements TabInterface
{
    protected $_wysiwygConfig;
    protected $_systemStore;
    protected $_websiteFactory;
    protected $_sliderHelper;
 
    public function __construct(
        \Magento\Backend\Block\Template\Context $context, 
        \Magento\Framework\Registry $registry, 
        \Magento\Framework\Data\FormFactory $formFactory,  
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig, 
        \Magento\Store\Model\WebsiteFactory $websiteFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Webstraxt\BannerManager\Helper\Data $sliderHelper,
        array $data = []
    ) 
    {
        $this->_systemStore = $systemStore;
        $this->_websiteFactory = $websiteFactory;
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->_sliderHelper  = $sliderHelper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Banner Information');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Banner Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('current_webstraxt_bannermanager_items');
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('item_');
        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Banner Information')]);
        if ($model->getId()) {
            $fieldset->addField('bannermanager_id', 'hidden', ['name' => 'bannermanager_id']);
        }
        $fieldset->addField(
            'title',
            'text',
            ['name' => 'title', 'label' => __('Title'), 'title' => __('Title'), 'required' => true]
        );
        
        $fieldset->addField(
            'slider_id',
            'select',
            [
                'label' => __('Slider'),
                'name' => 'slider_id',
                'values' => $this->_sliderHelper->getAvilableSlider(),
                'note' => 'select slider in which you want to show this banner',
            ]
        );
        $fieldset->addField(
            'url',
            'text',
            ['name' => 'url', 'label' => __('URL'), 'title' => __('URL')]
        );
        $fieldset->addField(
            'image',
            'image',
            [
                'name' => 'image',
                'label' => __('Banner'),
                'title' => __('Banner'),
                'required'  => true
            ]
        );
         $fieldset->addField(
            'alt_text',
            'text',
            [
                'name' => 'alt_text',
                'label' => __('Alt Text'),
                'title' => __('Alt Text'),
            ]
        );
          $fieldset->addField(
            'sort_order',
            'text',
            [
                'name' => 'sort_order',
                'label' => __('Sort Order'),
                'title' => __('Sort Order'),
                'note' => 'enter order in which you want show on slider',
                'class' => 'validate-number',
            ]
        );
        $fieldset->addField(
            'status',
            'select',
            ['name' => 'status', 'label' => __('Status'), 'title' => __('Status'),  'options'   => [0 => 'Disable', 1 => 'Enable'], 'required' => true,
                'note' => 'enable or disable banner',
            ]
        );
        $websites = $this->_websiteFactory->create()->getCollection()->toOptionArray();
        $fieldset->addField(
            'description',
            'editor',
            [
                'name' => 'description',
                'label' => __('Description'),
                'title' => __('Description'),
                'style' => 'height:20em;',
                'config'    => $this->_wysiwygConfig->getConfig(),
                'wysiwyg' => true
            ]
        );
        
        
        $form->setValues($model->getData());
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
