<?php
/**
 * @category   Webstraxt
 * @package    Webstraxt_BannerManager
 * @author     baliram@webstraxt.com
 * @copyright  Webstraxt Limited https://webstraxt.com/
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Webstraxt\BannerManager\Block;

/**
 * BannerManager content block
 */
class BannerManager extends \Magento\Framework\View\Element\Template
{
    /**
    * @var MODULE_ENABLE_SYS_PATH
    */

    const MODULE_ENABLE_SYS_PATH = 'BannerManagerModule/BannerManager/enable';

    /**
    * @var $_scopeConfig \Magento\Framework\App\Config\ScopeConfigInterface
    */

    protected $_scopeConfig;

    /**
    * @var $_model \Webstraxt\BannerManager\Model\BannerManager
    */

    protected $_model;

     /**
    * @var $_model \Magento\Store\Model\StoreManagerInterface
    */

    protected $_storeManager;

    protected $_sliderManagerFactory;

    protected $_banners;

    protected $_sliderConfig;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Webstraxt\BannerManager\Model\BannerManagerFactory $modelFactory,
        \Webstraxt\BannerManager\Model\ResourceModel\SliderManager\CollectionFactory $sliderManagerFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->_storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
        $this->_model       = $modelFactory;
        $this->_sliderManagerFactory = $sliderManagerFactory;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        //$this->pageConfig->getTitle()->set(__('Webstraxt BannerManager'));
        
        return parent::_prepareLayout();
    }

    /**
     * @return
     */
    protected function _toHtml()
    {
        
        return parent::_toHtml();
        
    }

    /**
    * Get Module Status
    *
    * @return  bool
    */
    public function getModuleStatus()
    {
        $moduleEnable = $this->_scopeConfig->getValue(self::MODULE_ENABLE_SYS_PATH, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $moduleEnable;
    }
    /**
    * Get Banner Collection
    *
    * @return  collection
    */
    public function getBannerCollection()
    {
        $collection  = $this->_model->create()->getCollection()->addFieldToFilter('status',1);
        return $collection;
    }
    /**
    * Get store identifier
    *
    * @return  int
    */
    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }
    /**
    * Get media url
    *
    * @return  string media url
    */
    public function getMediaUrl()
    {
        $currentStore = $this->_storeManager->getStore();
        $mediaUrl = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        return $mediaUrl;
    }


    /**
    * set  Slider Position
    *
    * @return  $this
    */
    public function setPosition($position)
    {  
        $sliderCollection = $this->_sliderManagerFactory
            ->create()
            ->addFieldToFilter('position', $position)
            ->addFieldToFilter('status', 1);

        $this->appendChildBlockSliders($sliderCollection);

        return $this;
    }

    /**
    * set template for block layout  
    *
    * @return  $this
    */
    public function appendChildBlockSliders(
        \Webstraxt\BannerManager\Model\ResourceModel\SliderManager\Collection $sliderCollection
    ) {
        $currentStoreId =  $this->getStoreId();
        foreach ($sliderCollection->getData() as $slider) 
        { 
            $sliderStoreIds = explode(',', $slider['store_id']);
            if($slider['slider_id'] && in_array($currentStoreId,$sliderStoreIds))
            {
                $this->setSliderConfig($slider);
                $this->_getBannerCollectionBySliderId();
                $this->setTemplate('Webstraxt_BannerManager::slider/main.phtml');    
            }
        }

        return $this;
    }

    /**
    * get banner coller by slider id
    *
    * @return 
    */
    public function _getBannerCollectionBySliderId()
    {
        $slider_id = $this->_sliderConfig['slider_id'];
        $bannerCollection  = $this->_model->create()->getCollection()->addFieldToFilter('status',1)->addFieldToFilter('slider_id',$slider_id)->setOrder('sort_order','ASC');

        $this->_setBanner($bannerCollection);
    }
    
  /**
    * set banner collection
    *
    * @return 
    */
    public function _setBanner($bannerCollection)
    {
        $this->_banners = $bannerCollection;
    }

    /**
    * get banner data 
    *
    * @return banner collection
    */
    public function getBanner()
    {
        return $this->_banners;
    }

    /**
    * set slider data in array
    *
    * @return 
    */
    public function setSliderConfig($slider)
    {

        $sliderData['slider_id'] = $slider['slider_id'];
        $sliderData['show_title'] = $slider['show_title'] ? $slider['show_title'] : false ;
        $sliderData['title'] = $slider['title'];
        $sliderData['status'] = $slider['status'];
        $sliderData['width'] = $slider['width'];
        $sliderData['height'] = $slider['height'];
        $sliderData['animation_type'] = $slider['animation_type']? $slider['animation_type']: 'slideInRight';
        $sliderData['store_id'] = explode(',', $slider['store_id']);
        $sliderData['slider_speed'] = $slider['slider_speed'] ? $slider['slider_speed'] : 2000 ;

         $this->_sliderConfig = $sliderData;   

    }

    /**
    * get slider data 
    *
    * @return slider data array
    */
    public function getSliderConfig()
    {
        return $this->_sliderConfig;
    }

}
