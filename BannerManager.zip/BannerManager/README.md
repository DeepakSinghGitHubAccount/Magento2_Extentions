# Webstraxt Banner Manager Magento 2  module

# How to use

1. Go to the backend

On the Magento Admin Panel, you navigate to the Webstraxt BannaerManager → Manage Slider 
and create a slider

2. Then navigate to the Webstraxt BannaerManager → Manage Banner 
and create a banner

2. Then check on front website

