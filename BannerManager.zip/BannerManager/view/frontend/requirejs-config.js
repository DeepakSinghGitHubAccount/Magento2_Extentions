var config = {
    map: {
        '*': {
            owl_carousel: 'Webstraxt_BannerManager/js/owl.carousel'
        }
    },
    shim: {
        owl_carousel: {
            deps: ['jquery']
        }
    }
};