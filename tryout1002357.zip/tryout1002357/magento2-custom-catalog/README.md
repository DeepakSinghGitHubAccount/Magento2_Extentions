# How to install this extension?

Under your root folder, run the following command lines:

- composer require php-cuong/magento2-currency-symbol-position
- php bin/magento setup:upgrade --keep-generated
- php bin/magento setup:di:compile
- php bin/magento cache:flush

# How to see the results

1. Go to the backend

On the Magento Admin Panel, you navigate to the Catalog → Currency → Custom catalog

