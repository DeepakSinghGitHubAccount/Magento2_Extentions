<?php

namespace Tryout\CustomCatalog\Model;

use Magento\Framework\Model\AbstractModel;
use Tryout\CustomCatalog\Api\dataSetterInterface;
use Tryout\CustomCatalog\Api\SubscriberInterface;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\MessageQueue\MessageLockException;
use Magento\Framework\MessageQueue\ConnectionLostException;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\MessageQueue\CallbackInvoker;
use Magento\Framework\MessageQueue\ConsumerConfigurationInterface;
use Magento\Framework\MessageQueue\EnvelopeInterface;
use Magento\Framework\MessageQueue\QueueInterface;
use Magento\Framework\MessageQueue\LockInterface;
use Magento\Framework\MessageQueue\MessageController;
use Magento\Framework\MessageQueue\ConsumerInterface;



class Subscriber implements SubscriberInterface
{
    /**
     * {@inheritdoc}
     */
    public function processData(dataSetterInterface $data)
    {
        echo 'Message received: ' . $data->getData() . PHP_EOL;
    }
}